$(document).ready(function () 
{
    // variabels initialization
    var message;
    var n_sender, z_sender, d_sender, e_sender;
    var n_receiver, z_receiver, d_receiver, e_receiver;
    var array_Of_words = [];
    var array_Of_Char = [];
    var array_Of_Num = [];
    var encrypted_message = [];
    var decrypted_message = [];
    
    //--------------------------------------------------------
	//this restricts the button to be disabled after one use
	$('.encryption').on('click', function() 
	{
    $(this).prop('disabled', true);
	});
	$('.decryption').on('click', function() 
	{
    $(this).prop('disabled', true);
	});
    $(".encryption").click(convert_char_to_number);
    $(".decryption").click(convert_number_to_char);
    //--------------------------------------------------------
 
    function convert_char_to_number() 
	{
		// convert the message from text to ASCII value
        message = $(".message").val();
		console.log("Entered Message is : ", message);
        array_Of_Char = message.split(""); // split the text to single characters
        console.log("Split the Input message into individual characters : " + array_Of_Char);
        for (let x in array_Of_Char) 
		{
			//convert the characters into the numbers
            array_Of_Num.push(array_Of_Char[x].charCodeAt(0)); 
        }
        console.log("Converting the characters to ASCII Equivalent Values : " + array_Of_Num);
		var t0 = performance.now();
        for (let z in array_Of_Num) 
		{
            encrypted_message.push(encryption(array_Of_Num[z])); // performs encryption
        }
        console.log("Cipher text is: " + encrypted_message);
        var dec_mess = "";
        for (let j in encrypted_message) 
		{
            dec_mess += encrypted_message[j];
        }
        $(".encrypted_message").text(dec_mess); // This allows the message to appear in textarea
		console.log("Encrypted message is: ", dec_mess);
		//calculates the performance
		var t1 = performance.now();
		console.log("Encryption time  " + (t1 - t0) + " milliseconds.")
    }
    //--------------------------------------------------------
    function convert_number_to_char() 
	{	// convert encrypted message from ASCII value to text 
		console.log("Cipher text is", encrypted_message);
		var t0 = performance.now();
        for (let j in encrypted_message) 
		{
			//performs decryption of encrypted message
            decrypted_message.push(decryption(encrypted_message[j])); 
        }
        console.log("Decrypted message is:" + decrypted_message);
        var result = "";
        for (let z in decrypted_message) 
		{
			// converts number to character
            result += String.fromCharCode(decrypted_message[z]); 
        }
		var t1 = performance.now();
        console.log("The Original Message is : " + result);
		console.log("Decryption time  " + (t1 - t0) + " milliseconds.")
        $(".decrypted_tex").text(result);
    }
    //-------------------------------------------------------------
    // sender operations
    $(".generate_sender").click(function () 
	{
		//takes input from the users
		console.log("Key Generation step");
        var ps = $(".ps").val();
		console.log("The First Prime Number p is ",ps);
        var qs = $(".qs").val();
		console.log("The Second Prime Number q is ",qs);

        // key generation
        if (test_prime(ps) === true && test_prime(qs) === true) 
		{
			var t0 = performance.now();
			//calculates the value of n
            n_sender = ps * qs;
			console.log("The Value of n=(p*q) is ", n_sender);
			//calculates euler's totient value
            z_sender = (ps - 1) * (qs - 1);
			console.log("Euler's Totient Function Φ=(p-1)*(q-1) is ", z_sender);
			for(e_sender=2;e_sender<z_sender;e_sender++)
			{
				//checks for gcd value to be in 1
				if (gcd(e_sender, z_sender) == 1) 
				{
					//calculates modinverse value
					d_sender = modInverse(e_sender, z_sender);
					if(gcd(d_sender,e_sender)==1)
					{
						$(".first_num_public_s").text(e_sender + ",");
						$(".second_num-public_s").text(n_sender);
						console.log("Calculating value of e from gcd(e,Φ) is :",e_sender);
						console.log("Calculating value of d from modinverse(d,Φ) is :",d_sender);
						var t1 = performance.now();
						console.log("Calculated Public Key e is :",(e_sender + "," + n_sender));
						console.log("Calculated Private Key d is :",(d_sender + "," + n_sender));
						$(".first_num_private_s").text(d_sender + ",");
						$(".second_num_private_s").text(n_sender);
						console.log("Key Generation time  " + (t1 - t0) + " milliseconds.")
						break;
					}
				}
            } 
        } 
		else 
		{
            alert("Please enter prime number only");
        }
    });
    //----------------------------------------------------
    // receiver operations
    $(".generate_receiver").click(function () 
	{
        var pr = $(".pr").val();
        var qr = $(".qr").val();
		
        // key generation
        if (test_prime(pr) === true && test_prime(qr) === true) 
		{
            n_receiver = pr * qr;
            z_receiver = (pr - 1) * (qr - 1);
			
			for(e_receiver=2;e_receiver<z_receiver;e_receiver++){
				
				if (gcd(e_receiver, z_receiver) == 1) 
				{
					d_receiver = modInverse(e_receiver, z_receiver);
					if(gcd(e_receiver,d_receiver)==1)
					{
					/*if (d_receiver == e_receiver) {
						d_receiver = d_receiver + n_receiver
					}*/
					$(".first_num_public_r").text(e_receiver + ",");
					$(".second_num-public_r").text(n_receiver);
					console.log("Calculating value of d from modInverse(e,Φ) is :",d_receiver);
					console.log("Calculated Private Key is :",(d_receiver + "," + n_receiver));
					$(".first_num_private_r").text(d_receiver + ",");
					$(".second_num_private_r").text(n_receiver);
					break;
					}
				}
            }
			
        } else {
            alert("Please enter primary number");
        }
		
    });
	//--------------------------------------------------------
	
	//performs encryption of the message using the formula
    function encryption(plainText) 
	{
		console.log("Performing Encryption using the formula c= m^{e} (mod n) is: ", plainText,e_sender,n_sender);
        var cipher = Math.pow(plainText, e_sender) % n_sender;
        return cipher;
    }
	
	//--------------------------------------------------------
//performs decryption using the formula
    function decryption(ciph) 
	{
		console.log("Performing Decryption using the formula m=c^{d}(mod n):",ciph,d_receiver,n_receiver);
		// console.log('ciphered text',ciph);
		// M1=Math.pow(ciph,d_receiver);
		// M = M1 % n_receiver;
		// console.log(M1,M);
		
        if (d_receiver % 2 == 0) 
		{ 
	// split large value of d, so can i calc math.pow(cipher,d).
            G = 1
            for (var j = 1; j <= d_receiver / 2; j++) 
			{
                M = (ciph * ciph) % n_receiver
                N = (M * N) % n_receiver
            }
        } 
		else 
		{
            N = ciph
            for (var j = 1; j <= d_receiver / 2; j++) 
			{
                M = (ciph * ciph) % n_receiver
                N = (M * N) % n_receiver
            }
        }
		// console.log('decryted text',N);
        return N;
    }
    
    //--------------------------------------------------------
    /* functions of gcd(),calculate modular multiplicated invers() and test primary number() */
    //--------------------------------------------------------
    function modInverse(a, m) 
	{ 
  [a, m] = [Number(a), Number(m)]
        if (Number.isNaN(a) || Number.isNaN(m)) 
		{
            return NaN // invalid input
        }
		a = (a%m)	
        // a = (a % m + m) % m
        if (!a || m < 2) 
		{
            return NaN //for invalid input
        }
		for (var x=1;x<m;x++)
		{
			if ((a * x) % m == 1)
			{
				
				return x
			}
		}
		return 1
	//if inverse does not exist
        if (a !== 1) 
		{
            return NaN 
        }
    }    
    //-----------------------------------------------------------
    function test_prime(n) 
	{ // test values of p and q if they are prime or not

        if (n === 1) 
		{
            return false;
        } 
		else if (n === 2) 
		{
            return true;
        } else 
		{
            for (var x = 2; x < n; x++) 
			{
                if (n % x === 0) {
                    return false;
                }
            }
            return true;
        }
    } // end of test_prime()
    //-------------------------------------------------------------
    function gcd(x, y) 
	{ // calculates the gcd of 2 numbers
        if ((typeof x !== 'number') || (typeof y !== 'number'))
            return false;
        x = Math.abs(x);
        y = Math.abs(y);
        while (y) 
		{
            var t = y;
            y = x % y;
            x = t;
        }
        return x; 
    } // end of gcd
    //--------------------------------------------------------------------------------------------------------------

});
