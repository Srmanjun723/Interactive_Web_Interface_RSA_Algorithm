$(document).ready(function () {
    //--------------------------------------------------------------------------------------------------------------
    // variabels initalization
    var message;
    var n, z, d, e;
    var arrOfword = [];
    var arrOfChar = [];
    var arrOfNum = [];
    var encrypted_message = [];
	
    //--------------------------------------------------------
    
    //--------------------------------------------------------
	$('.encryption').on('click', function() {
    $(this).prop('disabled', true);
	});
    $(".encryption").click(convert_char_to_number);
    $(".decryption").click(convert_number_to_char);
    //--------------------------------------------------------
 
    function encryption(plainText) 
	{
		console.log("Peforming Encryption using the formula c= m^{e} (mod n) is: ",plainText,e,n);
        var ci = Math.pow(plainText, e) % n;
		return ci;
    }

    //--------------------------------------------------------
    function decryption(cip,d) 
	{	
		message=0;		
		if (d % 2 == 0) 
		{ // split large value of d
		// calc math.pow(ciphe,d).
			G = 1
			for (var j = 1; j <= d / 2; j++) 
			{
				F = (cip * cip) % n
				G = (F * G) % n
				message=G;
			}
		} 
		else 
		{
			G = cip
			for (var j = 1; j <= d / 2; j++) 
			{
				F = (cip * cip) % n
				G = (F * G) % n
				message=G;
			}
		}
        return message;
    }
    //--------------------------------------------------------
    function convert_char_to_number() 
	{ // converting the text to encrypted message 
        message = $(".message").val();
        arrOfChar = message.split(""); // split the text to character
        console.log("Split the message into characters  : " + arrOfChar);
        for (let y in arrOfChar) 
		{
            arrOfNum.push(arrOfChar[y].charCodeAt(0)); // converting char to number
        }
        console.log("Converting the characters to ASCII Equivalent Value : " + arrOfNum);
		var w2 = performance.now();
        for (let o in arrOfNum) 
		{
            encrypted_message.push(encryption(arrOfNum[o])); // encryption done here
        }
		//{ if (x = true)
		// x =y 
        console.log("Cipher text: " + encrypted_message);
        var dec_mes = "";
        for (let x in encrypted_message) 
		{
            dec_mes += encrypted_message[x];
        }
        $(".encrypted_message").text(dec_mes); 
		console.log("Encrypted message: ", dec_mes);
		 var w1 = performance.now();
		console.log("Encryption  " + (w1 - w2) + " millisecond.")// appear message in textarea
    }
    //--------------------------------------------------------
    function convert_number_to_char() 
	{// convert encrypted message to text 
		var decrypted_message = [];
		console.log(encrypted_message);
		var t0 = performance.now();
		var an= new Map();
		d = 2;	
		while(d < 200)
		{	
			temp=[];
			if(gcd(e,d)==1)
			{
				for (let i in encrypted_message) {
					temp.push(decryption(encrypted_message[i],d));
				}
				an.set(d,temp);
			}
			d++;
		}
		
		console.log('results');
		for (var [key, value] of an) 
		{
			console.log("For D :", key);
			var t = "";
			for (let s in value) 
			{
				t+=String.fromCharCode(value[s]); // convert number to char
			}
			console.log("Text is :",t);
			an.set(key,t);
		}
		var w1 = performance.now();
		console.log("Decryption time  " + (w1 - t0) + " millisecond.")
		console.info(an);
		let formattedText = function(input){
			let formattedtring="";
			input.forEach(function(value, key) {
				formattedtring += `For D: ${key} the text is: ${value}\n`;
			});
			return formattedtring;
		}
		
        $(".decrypted_tex").text(formattedText(an));
    }
    //-------------------------------------------------------------
    // sending operation
    $(".generate_sender").click(function () {
		
        var ps = $(".ps").val();
		console.log("First Prime Number p is ",ps);
        var qs = $(".qs").val();
		console.log("Second Prime Number q is ",qs);

        // key generating
        if (test_prime(ps) === true && test_prime(qs) === true) 
{
            n = ps * qs;
			console.log("The Value of n=(p*q) is ", n);
            z = (ps - 1) * (qs - 1);
			console.log("Euler's Totient Function Φ=(p-1)*(q-1) is ", z);
			for(e=2;e<z;e++){
				
				if (gcd(e, z) == 1) {
					d = modInverse(e, z);
					if(gcd(d,e)==1)
					{
					if (d == e) 
					{
						d = d + n
					}
					$(".first_num_public_s").text(e + ",");
					$(".second_num-public_s").text(n);
					console.log("Calculating value of e from gcd(e,Φ) is :",e);
					console.log("Calculating value of d from modinverse(d,Φ) is :",d);
					$(".first_num_private_s").text(d + ",");
					$(".second_num_private_s").text(n);
					console.log("Calculated Public Key e is :",(e + "," + n));
					console.log("Calculated Private Key d is :",(d + "," + n));
					break;
					}
				}
            } 
			
        } else {
            alert("Please enter prime numbe only");
        }
    });
    //----------------------------------------------------
    // receive operation
    $(".geneate_receive").click(function () {
       
					$(".first_num_public_r").text(e + ",");
					$(".second_num-public_r").text(n);
			
    });
    //--------------------------------------------------------
    /* function of gcd(),calculate modular multiplicated inverse() and test primary number() */
    //--------------------------------------------------------
    function modInverse(a, m) 
	{ // calculate modular multiplicated inverse
        // validate inputs
  [a, m] = [Number(a), Number(m)]
        if (Number.isNaN(a) || Number.isNaN(m)) 
		{
            return NaN // invalid input
        }
        a = (a % m + m) % m
        if (!a || m < 2) {
            return NaN // invalid input
        }
        // find the gcd
        const s = []
        let b = m
        while (b) 
		{
		[a, b] = [b, a % b]
            s.push({
                a,
                b
            })
        }
        if (a !== 1) {
            return NaN // inverse doe not exists
        }
        // finding the inverse
        let x = 1
        let y = 0
        for (let j = s.length - 2; j >= 0; --j) 
		{
		[x, y] = [y, x - y * Math.floor(s[j].a / s[j].b)]
        }
        return (y % m + m) % m
    } // end of modInverse
    //-----------------------------------------------------------
    function test_prime(num) 
	{ // prime number or not
        if (num === 1) 
		{
            return false;
        } 
		else if (num === 2) 
		{
            return true;
        } 
		else 
		{
            for (var y = 2; y < num; y++) 
			{
                if (num % y === 0) 
				{
                    return false;
                }
            }
            return true;
        }
    } // end of tet_prime()
    //-------------------------------------------------------------
    function gcd(num1, num2) { // calculate greatet common divisor
        if ((typeof num1 !== 'number') || (typeof num2 !== 'number'))
		{
            return false;
		}
		//two numbers absolute value
        num1 = Math.abs(num1);
        num2 = Math.abs(num2);
        while (num2) 
		{
            var red = num2;
            num2 = num1 % num2;
            num1 = red;
        }
        return num1;
    } // end of greatet comman divisor
    //--------------------------------------------------------------------------------------------------------------

});
